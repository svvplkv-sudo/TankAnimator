package com.example.tankanimator.animation

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Surface-input H.264/MP4 exporter. renderFrame must draw one complete frame on the supplied Canvas. */
class MediaCodecVideoExporter {
    suspend fun export(
        context: Context,
        width: Int = 1280,
        height: Int = 720,
        fps: Int = 24,
        frameCount: Int,
        renderFrame: (Canvas, Int) -> Unit
    ): File = withContext(Dispatchers.IO) {
        require(width % 2 == 0 && height % 2 == 0) { "H.264 dimensions must be even" }
        require(frameCount > 0)
        val output = File(context.getExternalFilesDir(null) ?: context.filesDir, "tank_animation_${System.currentTimeMillis()}.mp4")
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfoCompat.COLOR_FORMAT_SURFACE)
            setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        var muxerStarted = false
        var trackIndex = -1
        val info = MediaCodec.BufferInfo()
        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            encoder.start()

            fun drain(endOfStream: Boolean) {
                var idleSpins = 0
                while (true) {
                    val index = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000 else 0)
                    when {
                        index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                            if (!endOfStream || idleSpins++ > 20) return
                        }
                        index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            check(!muxerStarted) { "Encoder output format changed twice" }
                            trackIndex = muxer!!.addTrack(encoder.outputFormat)
                            muxer.start(); muxerStarted = true
                        }
                        index >= 0 -> {
                            val buffer = encoder.getOutputBuffer(index)!!
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0) {
                                check(muxerStarted) { "Muxer has not started" }
                                buffer.position(info.offset); buffer.limit(info.offset + info.size)
                                muxer!!.writeSampleData(trackIndex, buffer, info)
                            }
                            val eos = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            encoder.releaseOutputBuffer(index, false)
                            if (eos) return
                        }
                    }
                }
            }

            for (frame in 0 until frameCount) {
                val canvas = inputSurface!!.lockCanvas(null)
                try {
                    canvas.drawColor(Color.TRANSPARENT)
                    renderFrame(canvas, frame)
                } finally {
                    inputSurface!!.unlockCanvasAndPost(canvas)
                }
                drain(false)
            }
            encoder.signalEndOfInputStream()
            drain(true)
            check(muxerStarted) { "No encoded frames were produced" }
            output
        } catch (t: Throwable) {
            output.delete()
            throw t
        } finally {
            runCatching { encoder.stop() }
            runCatching { encoder.release() }
            runCatching { inputSurface?.release() }
            runCatching { if (muxerStarted) muxer?.stop() }
            runCatching { muxer?.release() }
        }
    }

    private object MediaCodecInfoCompat { const val COLOR_FORMAT_SURFACE = 0x7F000789 }
}
