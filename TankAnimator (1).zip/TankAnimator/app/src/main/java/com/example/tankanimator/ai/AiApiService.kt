package com.example.tankanimator.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URL
import java.util.concurrent.TimeUnit

/** Cloud-only image generation. Never bundle model weights or provider secrets in the APK. */
class AiApiService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .callTimeout(120, TimeUnit.SECONDS)
        .build(),
    private val config: Config = Config()
) {
    data class Config(
        val provider: Provider = Provider.OPENAI,
        val apiKey: String = "",
        val replicateModelVersion: String = "",
        val proxyBaseUrl: String? = null,
        val removeBackgroundUrl: String? = null
    )
    enum class Provider { OPENAI, REPLICATE, STABILITY }

    companion object {
        const val STYLE_PROMPT = "Original 2D cartoon military vehicle, bold clean black outlines, flat cel shading, readable exaggerated shapes, side view, isolated on a plain light background, polished animation asset."
        const val SHOT_EFFECT_PROMPT = "A compact 2D cartoon tank muzzle flash with layered orange-yellow flame, dark smoke puffs and a few sparks, sprite-sheet friendly, transparent background."
    }

    suspend fun generateTank(userPrompt: String, transparent: Boolean = true): Bitmap = withContext(Dispatchers.IO) {
        val prompt = "$STYLE_PROMPT Subject: ${userPrompt.trim()}"
        val bytes = when (config.provider) {
            Provider.OPENAI -> generateOpenAi(prompt)
            Provider.REPLICATE -> generateReplicate(prompt)
            Provider.STABILITY -> generateStability(prompt)
        }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: error("AI provider returned data that is not a supported image")
        if (transparent) removeBackground(decoded) else decoded
    }

    suspend fun generateShotEffect(): Bitmap = withContext(Dispatchers.IO) {
        val bytes = when (config.provider) {
            Provider.OPENAI -> generateOpenAi(SHOT_EFFECT_PROMPT)
            Provider.REPLICATE -> generateReplicate(SHOT_EFFECT_PROMPT)
            Provider.STABILITY -> generateStability(SHOT_EFFECT_PROMPT)
        }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: error("Invalid effect image")
    }

    /** Uses a configured backend endpoint when available; otherwise returns the source unchanged. */
    private suspend fun removeBackground(source: Bitmap): Bitmap {
        val endpoint = config.removeBackgroundUrl ?: return source
        val stream = java.io.ByteArrayOutputStream()
        source.compress(Bitmap.CompressFormat.PNG, 100, stream)
        val body = JSONObject().put("image_base64", Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP))
            .toString().toRequestBody("application/json".toMediaType())
        val request = authorized(Request.Builder().url(endpoint).post(body)).build()
        val bytes = executeBytes(request)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: source
    }

    private suspend fun generateOpenAi(prompt: String): ByteArray {
        val body = JSONObject()
            .put("model", "gpt-image-1")
            .put("prompt", prompt)
            .put("size", "1024x1024")
            .put("n", 1)
            .toString().toRequestBody("application/json".toMediaType())
        val request = authorized(Request.Builder().url("https://api.openai.com/v1/images/generations").post(body)).build()
        val json = JSONObject(executeText(request))
        val item = json.getJSONArray("data").getJSONObject(0)
        val encoded = item.optString("b64_json")
        if (encoded.isNotBlank()) return Base64.decode(encoded, Base64.DEFAULT)
        val url = item.optString("url")
        require(url.isNotBlank()) { "OpenAI response did not contain image data" }
        return download(url)
    }

    private suspend fun generateStability(prompt: String): ByteArray {
        val body = JSONObject().put("prompt", prompt).put("output_format", "png")
            .toString().toRequestBody("application/json".toMediaType())
        val request = authorized(Request.Builder()
            .url("https://api.stability.ai/v2beta/stable-image/generate/core")
            .addHeader("Accept", "application/json")
            .post(body)).build()
        val json = JSONObject(executeText(request))
        return Base64.decode(json.getString("image"), Base64.DEFAULT)
    }

    private suspend fun generateReplicate(prompt: String): ByteArray {
        require(config.replicateModelVersion.isNotBlank()) { "Set Replicate model version in Config" }
        val body = JSONObject().put("version", config.replicateModelVersion)
            .put("input", JSONObject().put("prompt", prompt))
            .toString().toRequestBody("application/json".toMediaType())
        val base = config.proxyBaseUrl?.trimEnd('/') ?: "https://api.replicate.com"
        val createRequest = authorized(Request.Builder().url("$base/v1/predictions").post(body)).build()
        val created = JSONObject(executeText(createRequest))
        var status = created.optString("status")
        var result = created
        val getUrl = created.optString("urls").let { created.optJSONObject("urls")?.optString("get") }
        require(!getUrl.isNullOrBlank()) { "Replicate response did not include polling URL" }
        var attempts = 0
        while (status == "starting" || status == "processing") {
            check(attempts++ < 90) { "Replicate generation timed out" }
            kotlinx.coroutines.delay(2000)
            val poll = authorized(Request.Builder().url(getUrl).get()).build()
            result = JSONObject(executeText(poll))
            status = result.optString("status")
        }
        check(status == "succeeded") { "Replicate generation failed: ${result.optString("error")}" }
        val output = result.opt("output")
        val imageUrl = when (output) {
            is String -> output
            is org.json.JSONArray -> output.optString(0)
            else -> ""
        }
        require(imageUrl.startsWith("https://")) { "Replicate output image URL missing" }
        return download(imageUrl)
    }

    private fun authorized(builder: Request.Builder): Request.Builder {
        if (config.apiKey.isNotBlank()) builder.addHeader("Authorization", "Bearer ${config.apiKey}")
        return builder
    }

    private suspend fun executeText(request: Request): String = withContext(Dispatchers.IO) {
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            check(response.isSuccessful) { "AI API ${response.code}: $text" }
            text
        }
    }

    private suspend fun executeBytes(request: Request): ByteArray = withContext(Dispatchers.IO) {
        client.newCall(request).execute().use { response ->
            check(response.isSuccessful) { "AI API error: ${response.code}" }
            response.body?.bytes() ?: error("Empty image response")
        }
    }

    private suspend fun download(url: String): ByteArray = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(url).get().build()
        executeBytes(request)
    }
}
