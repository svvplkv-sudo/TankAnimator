package com.example.tankanimator.animation

import kotlin.math.PI

/** Lightweight 2D transform hierarchy. Coordinates and angles are in pixels/degrees. */
data class RigPart(
    val id: String,
    val tag: String,
    var x: Float = 0f,
    var y: Float = 0f,
    var rotationDeg: Float = 0f,
    var parentId: String? = null,
    var visible: Boolean = true
)

data class WorldTransform(val x: Float, val y: Float, val rotationDeg: Float)

class TankRigEngine {
    private val parts = linkedMapOf<String, RigPart>()
    private val wheelTravel = mutableMapOf<String, Float>()
    var wheelRadiusPx: Float = 18f

    fun addPart(part: RigPart) { require(part.id !in parts) { "Part ${part.id} already exists" }; parts[part.id] = part }
    fun getPart(id: String): RigPart? = parts[id]
    fun allParts(): List<RigPart> = parts.values.toList()

    fun attach(childId: String, parentId: String) {
        require(childId != parentId) { "A part cannot parent itself" }
        require(parts.containsKey(childId) && parts.containsKey(parentId)) { "Unknown rig part" }
        var cursor: String? = parentId
        while (cursor != null) {
            require(cursor != childId) { "Parenting would create a cycle" }
            cursor = parts[cursor]?.parentId
        }
        parts.getValue(childId).parentId = parentId
    }

    fun detach(partId: String) { parts[partId]?.parentId = null }

    /** Dragging a wheel/track along X rolls it by distance / circumference. */
    fun movePart(id: String, newX: Float, newY: Float) {
        val part = parts[id] ?: return
        val dx = newX - part.x
        part.x = newX; part.y = newY
        if (part.tag.equals("Каток", true) || part.tag.equals("Гусеница", true) || part.tag.equals("wheel", true) || part.tag.equals("track", true)) {
            val circumference = (2.0 * PI * wheelRadiusPx).toFloat().coerceAtLeast(1f)
            part.rotationDeg = (part.rotationDeg + dx / circumference * 360f) % 360f
            wheelTravel[id] = (wheelTravel[id] ?: 0f) + dx
        }
    }

    fun rotatePart(id: String, degrees: Float) { parts[id]?.rotationDeg = degrees }

    fun worldTransform(id: String): WorldTransform {
        val part = parts[id] ?: return WorldTransform(0f, 0f, 0f)
        val parentId = part.parentId ?: return WorldTransform(part.x, part.y, part.rotationDeg)
        val parent = worldTransform(parentId)
        val radians = Math.toRadians(parent.rotationDeg.toDouble())
        val rx = part.x * kotlin.math.cos(radians).toFloat() - part.y * kotlin.math.sin(radians).toFloat()
        val ry = part.x * kotlin.math.sin(radians).toFloat() + part.y * kotlin.math.cos(radians).toFloat()
        return WorldTransform(parent.x + rx, parent.y + ry, parent.rotationDeg + part.rotationDeg)
    }

    fun wheelDistance(id: String): Float = wheelTravel[id] ?: 0f

    companion object {
        fun createDefaultTank(): TankRigEngine = TankRigEngine().apply {
            addPart(RigPart("hull", "Корпус"))
            addPart(RigPart("turret", "Башня", x = 0f, y = -28f, parentId = "hull"))
            addPart(RigPart("barrel", "Дуло", x = 48f, y = -30f, parentId = "turret"))
            addPart(RigPart("road_wheels", "Каток", x = 0f, y = 24f, parentId = "hull"))
            addPart(RigPart("track", "Гусеница", x = 0f, y = 35f, parentId = "hull"))
        }
    }
}
