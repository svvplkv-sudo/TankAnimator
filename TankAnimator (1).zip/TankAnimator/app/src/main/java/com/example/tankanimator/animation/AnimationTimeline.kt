package com.example.tankanimator.animation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun AnimationTimeline(
    modifier: Modifier = Modifier,
    frameCount: Int = 24,
    onFrameSelected: (Int) -> Unit = {},
    onPlayStateChanged: (Boolean) -> Unit = {},
    onOnionSkinChanged: (Boolean) -> Unit = {}
) {
    var selectedFrame by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var onionSkin by remember { mutableStateOf(true) }
    Column(modifier.background(Color(0xFF171C25)).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { playing = !playing; onPlayStateChanged(playing) }) { Text(if (playing) "Pause" else "Play") }
            Text("Кадр ${selectedFrame + 1}/$frameCount", color = Color.White)
            Spacer(Modifier.weight(1f))
            FilterChip(selected = onionSkin, onClick = { onionSkin = !onionSkin; onOnionSkinChanged(onionSkin) }, label = { Text("Onion Skin") })
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items((0 until frameCount).toList()) { frame ->
                Box(
                    Modifier.size(width = 42.dp, height = 48.dp)
                        .background(if (frame == selectedFrame) Color(0xFFF2A93B) else Color(0xFF303846), RoundedCornerShape(5.dp))
                        .clickable { selectedFrame = frame; onFrameSelected(frame) },
                    contentAlignment = Alignment.Center
                ) { Text("${frame + 1}", color = if (frame == selectedFrame) Color.Black else Color.White) }
            }
        }
    }
}
