package com.example.tankanimator

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.example.tankanimator.ai.AiApiService
import com.example.tankanimator.animation.AnimationTimeline
import com.example.tankanimator.animation.RigPart
import com.example.tankanimator.animation.TankRigEngine
import com.example.tankanimator.drawing.DrawingCanvas
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TankAnimatorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TankAnimatorApp() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFF2A93B), background = Color(0xFF151922))) {
        Scaffold(
            containerColor = Color(0xFF151922),
            topBar = { TopAppBar(title = { Text("Tank Animator") }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF202630), titleContentColor = Color.White)) },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF202630)) {
                    listOf("Рисование", "Анимация", "ИИ-генератор").forEachIndexed { index, label ->
                        NavigationBarItem(selected = tab == index, onClick = { tab = index }, icon = {}, label = { Text(label) })
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> DrawingCanvas()
                    1 -> AnimationScreen()
                    else -> AiScreen()
                }
            }
        }
    }
}

@Composable
private fun AnimationScreen() {
    val rig = remember { TankRigEngine.createDefaultTank() }
    var selected by remember { mutableStateOf("hull") }
    var frame by remember { mutableIntStateOf(0) }
    var onion by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Иерархия объектов", color = Color.White, style = MaterialTheme.typography.titleMedium)
        rig.allParts().forEach { part ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected == part.id, onClick = { selected = part.id })
                Text("${part.tag}  ·  ${part.id}", color = Color.White)
                Spacer(Modifier.weight(1f))
                Text("${rig.worldTransform(part.id).rotationDeg.toInt()}°", color = Color.LightGray)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { rig.rotatePart(selected, (rig.getPart(selected)?.rotationDeg ?: 0f) + 5f) }) { Text("Повернуть +5°") }
            OutlinedButton(onClick = { rig.movePart("road_wheels", (rig.getPart("road_wheels")?.x ?: 0f) + 12f, 24f) }) { Text("Катки →") }
        }
        Text("Пробег катка: ${rig.wheelDistance("road_wheels").toInt()} px", color = Color.LightGray)
        Text("Таймлайн", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.weight(1f))
        AnimationTimeline(frameCount = 24, onFrameSelected = { frame = it }, onOnionSkinChanged = { onion = it })
        Text("Текущий кадр: ${frame + 1} · Onion Skin: ${if (onion) "вкл." else "выкл."}", color = Color.LightGray)
        Text("MP4: для production подключите VideoExporter к отрисовке кадров сцены.", color = Color(0xFFFFCC80))
    }
}

@Composable
private fun AiScreen() {
    var prompt by remember { mutableStateOf("Современный мультяшный средний танк") }
    var result by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("API не настроен. Добавьте ключ через backend или BuildConfig.") }
    val scope = rememberCoroutineScope()
    // Empty key is deliberate: never ship a real provider secret in the APK.
    val service = remember { AiApiService(AiApiService.Config(apiKey = "", provider = AiApiService.Provider.OPENAI)) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Облачная генерация", color = Color.White, style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Что нарисовать") }, modifier = Modifier.fillMaxWidth())
        Button(enabled = !busy && prompt.isNotBlank(), onClick = {
            busy = true; message = "Генерация…"
            scope.launch {
                runCatching { service.generateTank(prompt) }
                    .onSuccess { result = it; message = "Изображение получено" }
                    .onFailure { message = it.message ?: "Ошибка API" }
                busy = false
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Ожидание…" else "Сгенерировать танк / фон") }
        Button(enabled = !busy, onClick = {
            busy = true
            scope.launch {
                runCatching { service.generateShotEffect() }
                    .onSuccess { result = it; message = "Эффект выстрела получен — разместите его поверх дула" }
                    .onFailure { message = it.message ?: "Ошибка API" }
                busy = false
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ИИ-эффект выстрела") }
        Text(message, color = Color.LightGray)
        result?.let { Image(it.asImageBitmap(), contentDescription = "AI generated asset", modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) }
        Text("Поддерживаемые провайдеры: OpenAI Images, Replicate Predictions, Stability AI. Для удаления фона задайте removeBackgroundUrl.", color = Color.LightGray)
    }
}
