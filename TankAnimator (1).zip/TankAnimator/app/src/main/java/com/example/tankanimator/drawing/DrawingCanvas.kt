package com.example.tankanimator.drawing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File
import kotlin.math.min

private data class StrokeData(val points: List<Offset>, val color: Int, val width: Float, val erase: Boolean)
private data class LayerData(val name: String, val strokes: MutableList<StrokeData>, var visible: Boolean = true, var alpha: Float = 1f)

enum class DrawTool { BRUSH, ERASER, FILL }
enum class SymmetryAxis { NONE, VERTICAL, HORIZONTAL, BOTH }

@Composable
fun DrawingCanvas(
    modifier: Modifier = Modifier,
    onExported: (File) -> Unit = {}
) {
    val context = LocalContext.current
    val layers = remember { mutableStateListOf(LayerData("Слой 1", mutableListOf())) }
    var activeLayer by remember { mutableIntStateOf(0) }
    var tool by remember { mutableStateOf(DrawTool.BRUSH) }
    var symmetry by remember { mutableStateOf(SymmetryAxis.NONE) }
    var color by remember { mutableStateOf(Color(0xFF20242B)) }
    var brushSize by remember { mutableFloatStateOf(8f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableFloatStateOf(0f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var currentPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    val transformState = rememberTransformableState { zoomChange, panChange, rotationChange ->
        zoom = (zoom * zoomChange).coerceIn(0.25f, 6f)
        pan += panChange
        rotation += rotationChange
    }

    Column(modifier = modifier.fillMaxSize().background(Color(0xFF202630)).padding(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = tool == DrawTool.BRUSH, onClick = { tool = DrawTool.BRUSH }, label = { Text("Кисть") })
            FilterChip(selected = tool == DrawTool.ERASER, onClick = { tool = DrawTool.ERASER }, label = { Text("Ластик") })
            FilterChip(selected = tool == DrawTool.FILL, onClick = { tool = DrawTool.FILL }, label = { Text("Заливка") })
            FilterChip(selected = symmetry != SymmetryAxis.NONE, onClick = {
                symmetry = when (symmetry) { SymmetryAxis.NONE -> SymmetryAxis.VERTICAL; SymmetryAxis.VERTICAL -> SymmetryAxis.HORIZONTAL; SymmetryAxis.HORIZONTAL -> SymmetryAxis.BOTH; SymmetryAxis.BOTH -> SymmetryAxis.NONE }
            }, label = { Text("Симм.: ${symmetry.name}") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Размер ${brushSize.toInt()}", color = Color.White)
            Slider(value = brushSize, onValueChange = { brushSize = it }, valueRange = 1f..40f, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(Color.Black, Color(0xFF315B36), Color(0xFFB8A36A), Color(0xFFB83A32), Color.White).forEach { swatch ->
                Surface(onClick = { color = swatch }, color = swatch, shape = RoundedCornerShape(50), modifier = Modifier.size(28.dp)) {}
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { layers.add(LayerData("Слой ${layers.size + 1}", mutableListOf())); activeLayer = layers.lastIndex }) { Text("+ Слой") }
            TextButton(onClick = { if (layers.size > 1) { layers.removeAt(activeLayer.coerceIn(0, layers.lastIndex)); activeLayer = 0 } }) { Text("−") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            layers.forEachIndexed { index, layer ->
                FilterChip(selected = activeLayer == index, onClick = { activeLayer = index }, label = { Text(if (layer.visible) layer.name else "◌ ${layer.name}") })
                if (index == activeLayer) TextButton(onClick = { layer.visible = !layer.visible }) { Text(if (layer.visible) "Скрыть" else "Показать") }
            }
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Непрозрачность", color = Color.White)
            Slider(value = layers.getOrNull(activeLayer)?.alpha ?: 1f, onValueChange = { value -> layers.getOrNull(activeLayer)?.alpha = value }, valueRange = 0f..1f, modifier = Modifier.weight(1f))
        }
        Canvas(
            modifier = Modifier.weight(1f).fillMaxWidth().background(Color(0xFFF4F1E8), RoundedCornerShape(8.dp))
                .transformable(transformState)
                .pointerInput(activeLayer, tool, symmetry, color, brushSize) {
                    detectDragGestures(onDragStart = { currentPoints = listOf(it) }, onDrag = { change, _ ->
                        currentPoints = currentPoints + change.position
                        change.consume()
                    }, onDragEnd = {
                        val layer = layers.getOrNull(activeLayer) ?: return@detectDragGestures
                        if (tool == DrawTool.FILL) {
                            // Простая заливка фона текущего слоя: отдельный непрозрачный мазок.
                            layer.strokes.add(StrokeData(listOf(Offset.Zero, Offset(size.width, size.height)), color.toArgbInt(), size.width.coerceAtLeast(size.height), false))
                        } else layer.strokes.add(StrokeData(currentPoints, color.toArgbInt(), brushSize, tool == DrawTool.ERASER))
                        currentPoints = emptyList()
                    })
                }
        ) {
            drawIntoCanvas { canvas ->
                val native = canvas.nativeCanvas
                val save = native.save()
                native.translate(size.width / 2f + pan.x, size.height / 2f + pan.y)
                native.rotate(rotation)
                native.scale(zoom, zoom)
                native.translate(-size.width / 2f, -size.height / 2f)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
                layers.filter { it.visible }.forEach { layer ->
                    layer.strokes.forEach { stroke ->
                        paint.color = stroke.color
                        paint.strokeWidth = stroke.width
                        paint.alpha = (255 * layer.alpha).toInt().coerceIn(0, 255)
                        paint.xfermode = if (stroke.erase) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
                        drawStroke(native, stroke.points, paint, symmetry, size.width, size.height)
                    }
                }
                paint.xfermode = null
                paint.color = color.toArgbInt(); paint.strokeWidth = brushSize
                drawStroke(native, currentPoints, paint, symmetry, size.width, size.height)
                native.restoreToCount(save)
            }
        }
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Масштаб: ${(zoom * 100).toInt()}%", color = Color.White)
            TextButton(onClick = { exportPng(context, layers, onExported) }) { Text("Экспорт PNG") }
        }
    }
}

private fun drawStroke(canvas: AndroidCanvas, points: List<Offset>, paint: Paint, symmetry: SymmetryAxis, width: Float, height: Float) {
    if (points.isEmpty()) return
    fun one(mirrorX: Boolean, mirrorY: Boolean) {
        val path = Path()
        points.forEachIndexed { i, p ->
            val x = if (mirrorX) width - p.x else p.x
            val y = if (mirrorY) height - p.y else p.y
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        if (points.size == 1) { val p = points.first(); canvas.drawCircle(if (mirrorX) width-p.x else p.x, if (mirrorY) height-p.y else p.y, paint.strokeWidth/2f, paint) }
        else canvas.drawPath(path, paint)
    }
    one(false, false)
    if (symmetry == SymmetryAxis.VERTICAL || symmetry == SymmetryAxis.BOTH) one(true, false)
    if (symmetry == SymmetryAxis.HORIZONTAL || symmetry == SymmetryAxis.BOTH) one(false, true)
    if (symmetry == SymmetryAxis.BOTH) one(true, true)
}

private fun exportPng(context: Context, layers: List<LayerData>, callback: (File) -> Unit) {
    val bitmap = Bitmap.createBitmap(1024, 1024, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    layers.filter { it.visible }.forEach { layer ->
        layer.strokes.forEach { stroke ->
            paint.color = stroke.color; paint.strokeWidth = stroke.width; paint.alpha = (255 * layer.alpha).toInt()
            val path = Path(); stroke.points.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
            if (stroke.erase) paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) else paint.xfermode = null
            canvas.drawPath(path, paint)
        }
    }
    paint.xfermode = null
    val dir = File(context.filesDir, "assets").apply { mkdirs() }
    val file = File(dir, "tank_asset_${System.currentTimeMillis()}.png")
    file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bitmap.recycle(); callback(file)
}

private fun Color.toArgbInt(): Int = android.graphics.Color.argb((alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt())
