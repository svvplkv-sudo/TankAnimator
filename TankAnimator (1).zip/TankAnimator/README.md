# Tank Animator

Android Studio project, Kotlin + Jetpack Compose, minSdk 26 / compileSdk 36.

## Build

1. Open this folder in Android Studio (JDK 17).
2. Let Gradle sync download dependencies.
3. Run `app` on an emulator/device.

## Important implementation notes

- `DrawingCanvas.kt`: local vector-like stroke layers, brush/eraser, multi-touch transform, symmetry and transparent PNG export into `filesDir/assets`.
- `AnimationTimeline.kt`: frame selection, play/pause state and onion-skin toggle UI.
- `TankRigEngine.kt`: parent-child transforms, independent rotations and wheel/track rolling.
- `MediaCodecVideoExporter.kt`: H.264 surface-input MP4 exporter; pass a scene renderer callback for each frame.
- `AiApiService.kt`: cloud HTTP clients for OpenAI Images, Replicate Predictions and Stability AI, plus optional background-removal endpoint.
- Provider keys are intentionally blank. Use a backend proxy in production; never hardcode provider keys in a distributed APK.

The timeline is a UI/control layer, not yet a full keyframe interpolation editor. The MP4 encoder is implemented as a reusable renderer-callback API; wire it to the scene renderer to export the actual animation. The current fill action is a simple layer mark, not a pixel flood-fill. PNG export currently exports drawing strokes at 1024x1024; it does not include a full scene compositor.
